﻿ОБЩИЙ ПРИНТЕР: Windows <-> Windows, Windows <-> Astra Linux, Linux <-> Linux

Порядок: сначала "Открыть доступ" на компьютере, к которому воткнут принтер,
потом "Подключить" на всех остальных.

WINDOWS (printer.bat, сам попросит права администратора)
  1  Открыть доступ к принтеру этого компьютера   — для других Windows и для Linux
  2  Подключить принтер с компьютера Linux        — печать через порт 9100
  3  Подключить принтер с другого компьютера Windows — через общий доступ (SMB)

ASTRA LINUX (sudo bash printer.sh)
  1  Открыть доступ к принтеру этого компьютера   — CUPS по IPP (631) и порт 9100 для Windows
  2  Подключить принтер с компьютера Windows      — через smb://
  3  Подключить принтер с другого компьютера Linux — через ipp://

Логин и пароль для Linux печатает пункт 1 на Windows. Пароль хранится
в printer-pass.txt рядом с printer.ps1 и при повторных запусках не меняется.

Требования: Windows 8/10/11; на Linux — CUPS (в Astra стоит из коробки).
Если не печатается с Windows на Linux: systemctl status printer-raw.socket
Если не печатается с Linux на Windows: systemctl status cups, lpstat -t

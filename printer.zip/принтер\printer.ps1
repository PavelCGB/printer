﻿#Requires -RunAsAdministrator
# Общий принтер: Windows <-> Windows и Windows <-> Astra Linux.
# Запуск: printer.bat (сам попросит права администратора).
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$passFile = Join-Path $here 'printer-pass.txt'
$shareUser = 'printer'

if (-not (Get-Command Get-Printer -ErrorAction SilentlyContinue)) {
    throw 'Нужны Windows 8 / 10 / 11: в Windows 7 нет командлетов печати. Подключите принтер вручную через "Устройства и принтеры".'
}

function Choose($title, $items) {
    $items = @($items)
    if ($items.Count -eq 0) { throw "Нечего выбрать: $title" }
    if ($items.Count -eq 1) { return $items[0] }
    Write-Host ""
    Write-Host $title
    for ($i = 0; $i -lt $items.Count; $i++) { Write-Host "  $($i + 1)) $($items[$i])" }
    do { $n = Read-Host 'Номер' } until (($n -as [int]) -ge 1 -and ($n -as [int]) -le $items.Count)
    return $items[[int]$n - 1]
}

function Yes($text) { return ((Read-Host "$text (д/н)") -match '^[дДyY]') }

# IPv4 этого компьютера, без виртуальных адаптеров (WMI — работает и там, где нет Get-NetIPAddress)
function LanIPs {
    $bad = 'Virtual|vEthernet|WSL|Hyper-V|VMware|VirtualBox|Loopback|TAP|Bluetooth|Tunnel|VPN|WireGuard|OpenVPN|ZeroTier|Tailscale'
    $all = @(Get-WmiObject Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=TRUE' |
             Where-Object { $_.IPAddress })
    $ips = @($all | Where-Object { $_.Description -notmatch $bad } | ForEach-Object { $_.IPAddress } |
             Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' -and $_ -notmatch '^(127|169\.254)\.' })
    if ($ips.Count -eq 0) {
        $ips = @($all | ForEach-Object { $_.IPAddress } |
                 Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' -and $_ -notmatch '^(127|169\.254)\.' })
    }
    $ips
}

# Проверка TCP-порта без Test-NetConnection (его нет на части систем)
function PortOpen($addr, $port) {
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $t = $c.BeginConnect($addr, $port, $null, $null)
        $ok = $t.AsyncWaitHandle.WaitOne(2000, $false)
        return ($ok -and $c.Connected)
    } catch { return $false } finally { $c.Close() }
}

# Принтеры, которые можно открыть для сети: локальные, не виртуальные,
# и не те, что сами подключены к другому компьютеру (порт Linux_...)
function LocalPrinters {
    @(Get-Printer |
      Where-Object { $_.Type -eq 'Local' -and $_.PortName -notmatch '^Linux_' -and $_.Name -notmatch 'PDF|XPS|Fax|OneNote' } |
      ForEach-Object Name)
}

# ======================= 1. ОТКРЫТЬ ПРИНТЕР ЭТОГО КОМПЬЮТЕРА =======================
function Share {
    $printer = Choose 'Какой принтер этого компьютера открыть для сети?' (LocalPrinters)

    # В имени общего доступа — только латиница: Linux подставляет его в адрес smb://
    $share = $printer -replace '[^A-Za-z0-9]', ''
    if (-not $share) { $share = 'Printer' }
    if ($share.Length -gt 20) { $share = $share.Substring(0, 20) }
    Set-Printer -Name $printer -Shared $true -ShareName $share -Published $false

    if ((Get-Service LanmanServer -ErrorAction SilentlyContinue).Status -ne 'Running') { Start-Service LanmanServer }
    Enable-NetFirewallRule -Group '@FirewallAPI.dll,-28502' -ErrorAction SilentlyContinue

    # Учётка для входа с Linux: у обычного пользователя часто нет пароля, а без пароля SMB не пускает.
    # Пароль создаётся один раз и лежит рядом с программой, иначе Linux пришлось бы переподключать каждый запуск.
    $pass = $null
    if (Test-Path $passFile) { $pass = ([System.IO.File]::ReadAllText($passFile)).Trim() }
    if (-not $pass) {
        $pass = -join ((48..57 + 65..90 + 97..122) | Get-Random -Count 12 | ForEach-Object { [char]$_ })
        [System.IO.File]::WriteAllText($passFile, $pass + "`r`n")
        & icacls $passFile /inheritance:r /grant:r '*S-1-5-32-544:F' '*S-1-5-18:F' | Out-Null
    }
    $sec = ConvertTo-SecureString $pass -AsPlainText -Force
    if (Get-LocalUser $shareUser -ErrorAction SilentlyContinue) {
        Set-LocalUser $shareUser -Password $sec
    } else {
        New-LocalUser $shareUser -Password $sec -PasswordNeverExpires -AccountNeverExpires -Description 'Печать с Linux' | Out-Null
    }
    try { Add-LocalGroupMember -SID 'S-1-5-32-545' -Member $shareUser } catch { }   # 545 = группа "Пользователи"

    # Не показывать эту учётку на экране входа
    $k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList'
    if (-not (Test-Path $k)) { New-Item $k -Force | Out-Null }
    New-ItemProperty -Path $k -Name $shareUser -Value 0 -PropertyType DWord -Force | Out-Null

    $ips = @(LanIPs)
    if ($ips.Count -eq 0) { $ips = @('<IP этого компьютера>') }
    Write-Host ""
    Write-Host "Готово. Принтер '$printer' открыт для сети как '$share'." -ForegroundColor Green
    Write-Host "  Windows: printer.bat -> пункт 3, введите $($ips[0]) и логин/пароль ниже"
    Write-Host "  Linux:   sudo bash printer.sh -> пункт 2, введите $($ips[0]) и логин/пароль ниже"
    Write-Host ""
    Write-Host "  IP:       $($ips -join ' или ')"
    Write-Host "  Путь:     \\$($ips[0])\$share"
    Write-Host "  Принтер:  $share"
    Write-Host "  Логин:    $shareUser"
    Write-Host "  Пароль:   $pass" -ForegroundColor Yellow
    Write-Host "  (пароль сохранён в printer-pass.txt и при повторных запусках не меняется)"

    # Windows не пускает общий доступ в сетях "Общедоступная"
    if (Get-Command Get-NetConnectionProfile -ErrorAction SilentlyContinue) {
        $pub = @(Get-NetConnectionProfile | Where-Object { $_.NetworkCategory -eq 'Public' })
        if ($pub.Count -gt 0) {
            Write-Host "  [!] Сеть '$($pub[0].Name)' помечена как 'Общедоступная' — Windows может блокировать общий доступ. Смените её на 'Частная'." -ForegroundColor Yellow
        }
    }
}

# ======================= 2. ПОДКЛЮЧИТЬ ПРИНТЕР С LINUX =======================
function ConnectFromLinux {
    $ip = (Read-Host 'IP компьютера с Linux').Trim()
    if (-not $ip) { return }
    if (-not (PortOpen $ip 9100)) {
        throw "Нет связи с ${ip}:9100. На Linux сначала запустите printer.sh -> пункт 1 (открыть доступ)."
    }

    # Linux сам переводит PostScript в язык своего принтера, драйвер конкретной модели тут не нужен
    $drv = $null
    foreach ($d in @('Microsoft PS Class Driver', 'MS Publisher Imagesetter')) {
        if (Get-PrinterDriver -Name $d -ErrorAction SilentlyContinue) { $drv = $d; break }
        try { Add-PrinterDriver -Name $d -ErrorAction Stop; $drv = $d; break } catch { }
    }
    if (-not $drv) { throw 'Не найден драйвер PostScript ("Microsoft PS Class Driver"). Установите его в Windows.' }

    $port = "Linux_$ip"
    $name = "Принтер Linux ($ip)"
    if (-not (Get-PrinterPort -Name $port -ErrorAction SilentlyContinue)) {
        Add-PrinterPort -Name $port -PrinterHostAddress $ip -PortNumber 9100
    }
    if (Get-Printer -Name $name -ErrorAction SilentlyContinue) {
        Write-Host "Принтер '$name' уже подключён." -ForegroundColor Yellow
    } else {
        Add-Printer -Name $name -DriverName $drv -PortName $port
        Write-Host "Готово. Принтер '$name' подключён (драйвер: $drv)." -ForegroundColor Green
    }
    if (Yes 'Напечатать тестовую страницу?') {
        Get-CimInstance Win32_Printer -Filter "Name='$name'" | Invoke-CimMethod -MethodName PrintTestPage | Out-Null
    }
}

# ======================= 3. ПОДКЛЮЧИТЬ ПРИНТЕР С ДРУГОГО WINDOWS =======================
function ConnectFromWindows {
    $target = (Read-Host 'IP или имя компьютера с Windows, где принтер уже открыт для сети').Trim()
    if (-not $target) { return }
    if (-not (PortOpen $target 445)) {
        throw "Нет связи с ${target}:445. На том компьютере включите общий доступ к файлам и принтерам (printer.bat -> пункт 1), сеть не должна быть 'Общедоступная'."
    }

    # Учётки сохраняем для этого компьютера: Windows сам подставит их при подключении принтера,
    # поэтому проверка входа через ipc$ тут не нужна (она падает, даже когда печать работает)
    & net use "\\$target\ipc$" /delete 2>&1 | Out-Null
    $user = (Read-Host 'Логин на том компьютере (Enter — текущая учётная запись Windows)').Trim()
    if ($user) {
        $pass = Read-Host "Пароль для $user"
        & cmdkey "/add:$target" "/user:$user" "/pass:$pass" | Out-Null
        if ($LASTEXITCODE -ne 0) { throw 'Windows не смог сохранить логин/пароль (cmdkey).' }
    }

    # Список общих принтеров иногда не отдаётся — тогда имя вводят вручную
    $shares = @()
    $err = ''
    for ($i = 1; $i -le 3 -and $shares.Count -eq 0; $i++) {
        $out = (& net view "\\$target" 2>&1 | Out-String)
        $shares = @([regex]::Matches($out, '(?m)^\s*(\S+)\s+Print\s') | ForEach-Object { $_.Groups[1].Value })
        if ($shares.Count -eq 0) {
            $err = (@($out.Trim() -split "`r?`n" | Where-Object { $_ }) | Select-Object -Last 1)
            Start-Sleep -Seconds 2
        }
    }

    $share = $null
    if ($shares.Count -gt 0) {
        $share = Choose "Какой принтер подключить с $target?" $shares
    } else {
        if ($err) { Write-Host "Список общих принтеров получить не удалось: $err" -ForegroundColor Yellow }
        Write-Host 'Имя общего принтера напечатал пункт 1 на том компьютере (строка "как ...").'
        $share = (Read-Host 'Имя общего принтера').Trim()
    }
    if (-not $share) { throw 'Имя принтера не задано.' }

    $conn = "\\$target\$share"
    $ok = [bool](Get-Printer -Name $conn -ErrorAction SilentlyContinue)
    if ($ok) {
        Write-Host "Принтер '$conn' уже подключён." -ForegroundColor Yellow
    } else {
        for ($i = 1; $i -le 2 -and -not $ok; $i++) {
            try { Add-Printer -ConnectionName $conn; $ok = $true } catch { }
            if (-not $ok) { & rundll32 printui.dll,PrintUIEntry /in /n "$conn" }
            if (-not $ok) { Start-Sleep -Seconds 3; $ok = [bool](Get-Printer -Name $conn -ErrorAction SilentlyContinue) }
        }
    }
    if (-not $ok) {
        Write-Host ""
        Write-Host "Не удалось подключить $conn." -ForegroundColor Red
        Write-Host "Что проверить на компьютере ${target}:"
        Write-Host "  1) принтер открыт и называется так же:   net share"
        Write-Host "  2) сеть не 'Общедоступная' и разрешён общий доступ к файлам и принтерам (порт 445)"
        Write-Host "  3) SMB включён:   Get-SmbServerConfiguration | Format-List EnableSMB1Protocol,EnableSMB2Protocol"
        Write-Host "  4) для локальной учётки:  wmic useraccount where name='$shareUser' get disabled"
        Write-Host "  5) проверьте вручную и посмотрите текст ошибки:   net use \\$target\$share"
        Write-Host "  6) если по IP не выходит — запустите снова и введите имя компьютера вместо IP"
        throw 'Подключение не удалось.'
    }
    Write-Host "Готово. Принтер '$conn' подключён." -ForegroundColor Green
    if (Yes 'Напечатать тестовую страницу?') {
        & rundll32 printui.dll,PrintUIEntry /k /n "$conn"
    }
}

# ======================= МЕНЮ =======================
try {
    $mode = Choose 'Что сделать?' @(
        'Открыть доступ к принтеру этого компьютера (для Windows и Linux)',
        'Подключить принтер с компьютера Linux',
        'Подключить принтер с другого компьютера Windows')
    if ($mode -like 'Открыть*') { Share }
    elseif ($mode -like '*Linux*') { ConnectFromLinux }
    else { ConnectFromWindows }
} catch {
    Write-Host ""
    Write-Host ("ОШИБКА: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Если не запускается печать с Linux — проверьте на Linux: systemctl status printer-raw.socket'
}

#!/bin/bash
# Общий принтер: Linux <-> Windows и Linux <-> Linux (Astra Linux / Debian, CUPS).
# Запуск: sudo bash printer.sh
set -e
[ "$EUID" -eq 0 ] || exec sudo bash "$0" "$@"

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; N=$'\e[0m'
ok()   { echo "  ${G}[OK]${N} $*"; }
warn() { echo "  ${Y}[!]${N}  $*"; }
die()  { echo "${R}ОШИБКА:${N} $*"; exit 1; }

ask() {  # вопрос, значение по умолчанию
  local a p="$1" d="${2-}"
  read -rp "$p${d:+ [$d]}: " a
  printf '%s\n' "${a:-$d}"
}
ask_pass() { local a; read -rsp "$1" a; echo >&2; printf '%s' "$a"; }
yes_no() { local a; read -rp "$1 (д/н) " a; [ "${a:0:1}" = "д" ] || [ "${a:0:1}" = "y" ] || [ "${a:0:1}" = "Y" ]; }

port_open() { timeout 3 bash -c "exec 3<>/dev/tcp/$1/$2" 2>/dev/null; }

choose_item() {  # заголовок, варианты... -> выбранный вариант
  local title="$1"; shift
  [ $# -gt 0 ] || return 1
  if [ $# -eq 1 ]; then printf '%s\n' "$1"; return 0; fi
  echo >&2; echo "$title" >&2
  local i=1 x
  for x in "$@"; do echo "  $i) $x" >&2; i=$((i+1)); done
  local n; read -rp "Номер: " n
  [[ "$n" =~ ^[0-9]+$ ]] && [ "$n" -ge 1 ] && [ "$n" -le $# ] || return 1
  printf '%s\n' "${!n}"
}

urlenc() {  # логин/пароль не должны ломать адрес smb://
  if command -v python3 >/dev/null 2>&1; then
    python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1],safe=""))' "$1"
  else
    printf '%s' "$1"
  fi
}

local_queues() {  # принтеры, подключённые прямо к этому ПК (USB/LPT)
  lpstat -v 2>/dev/null | sed -n 's/^device for \(.*\): \(.*\)$/\1|\2/p' |
    while IFS='|' read -r n uri; do
      case "$uri" in
        usb:*|parallel:*|serial:*|hp:*|/dev/*) printf '%s\n' "$n" ;;
      esac
    done
}

# ======================= 1. ОТКРЫТЬ ПРИНТЕР ЭТОГО КОМПЬЮТЕРА =======================
share() {
  command -v lpstat >/dev/null 2>&1 || die "Нет CUPS. Установите: apt-get install cups"
  mapfile -t list < <(local_queues)
  if [ ${#list[@]} -eq 0 ]; then
    warn "Не нашёл принтер, подключённый прямо к этому ПК — показываю все очереди"
    mapfile -t list < <(lpstat -e 2>/dev/null || true)
  fi
  [ ${#list[@]} -gt 0 ] || die "Принтеров нет. Сначала установите принтер на этом компьютере."
  local p; p=$(choose_item "Какой принтер открыть для сети?" "${list[@]}") || die "Отменено."
  ok "Принтер: $p"

  # CUPS отдаёт очередь по IPP (порт 631) для Linux; порт 9100 принимает PostScript от Windows.
  # shortcut: на 9100 один принтер — повторный запуск переключает его на выбранную очередь
  if command -v cupsctl >/dev/null 2>&1; then
    cupsctl --share-printers --remote-any >/dev/null || warn "CUPS не включил общий доступ"
    systemctl restart cups >/dev/null 2>&1 || warn "Не удалось перезапустить CUPS"
  fi
  lpadmin -p "$p" -o printer-is-shared=true

  cat > /etc/systemd/system/printer-raw.socket <<EOF
[Socket]
ListenStream=9100
Accept=yes

[Install]
WantedBy=sockets.target
EOF
  cat > /etc/systemd/system/printer-raw@.service <<EOF
[Service]
ExecStart=/usr/bin/lp -d "$p" -t Windows
StandardInput=socket
StandardOutput=journal
StandardError=journal
EOF
  systemctl daemon-reload
  systemctl enable printer-raw.socket >/dev/null 2>&1 || true
  systemctl restart printer-raw.socket

  if command -v ufw >/dev/null 2>&1 && ufw status | grep -qw active; then
    ufw allow 631/tcp >/dev/null
    ufw allow 9100/tcp >/dev/null
  fi
  if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
    firewall-cmd --permanent --add-port=631/tcp >/dev/null
    firewall-cmd --permanent --add-port=9100/tcp >/dev/null
    firewall-cmd --reload >/dev/null
  fi

  echo
  echo "Готово. Принтер $p открыт для сети."
  echo "IP этого компьютера: $(hostname -I)"
  echo "  Windows: printer.bat -> пункт 2, введите этот IP"
  echo "  Linux:   sudo bash printer.sh -> пункт 3, введите этот IP"
}

# ======================= 2. ПОДКЛЮЧИТЬ ПРИНТЕР С WINDOWS =======================
connect_windows() {
  local ip; ip=$(ask "IP компьютера с Windows")
  [ -n "$ip" ] || die "IP не задан."
  port_open "$ip" 445 || die "Нет связи с $ip:445. На Windows сначала запустите printer.bat -> пункт 1."
  if ! { command -v smbclient >/dev/null 2>&1 && [ -e /usr/lib/cups/backend/smb ]; }; then
    echo "  Ставлю smbclient..."
    apt-get install -y smbclient >/dev/null || die "Не удалось установить smbclient (нужен интернет или диск с пакетами)."
  fi
  local user pass
  user=$(ask "Логин" printer)
  pass=$(ask_pass "Пароль (его показала программа на Windows): ")
  mapfile -t shares < <(smbclient -L "//$ip" -U "$user%$pass" -g 2>/dev/null | awk -F'|' '$1=="Printer"{print $2}')
  [ ${#shares[@]} -gt 0 ] || die "Не вижу общих принтеров на $ip. Проверьте логин/пароль и пункт 1 на Windows."
  local share; share=$(choose_item "Какой принтер подключить?" "${shares[@]}") || die "Отменено."
  install_queue "$share" "smb://$(urlenc "$user"):$(urlenc "$pass")@$ip/$share"
}

# ======================= 3. ПОДКЛЮЧИТЬ ПРИНТЕР С LINUX =======================
connect_linux() {
  local ip; ip=$(ask "IP компьютера с Linux")
  [ -n "$ip" ] || die "IP не задан."
  port_open "$ip" 631 || die "Нет связи с $ip:631. На том компьютере сначала запустите printer.sh -> пункт 1."
  mapfile -t qs < <(lpstat -h "$ip:631" -a 2>/dev/null | awk 'NF{print $1}' | sort -u || true)
  local queue
  if [ ${#qs[@]} -gt 0 ]; then
    queue=$(choose_item "Какой принтер подключить с $ip?" "${qs[@]}") || die "Отменено."
  else
    queue=$(ask "Имя очереди на $ip" "HP1020")
  fi
  [ -n "$queue" ] || die "Имя очереди не задано."
  install_queue "$queue" "ipp://$ip:631/printers/$queue"
}

# ======================= СОЗДАТЬ ОЧЕРЕДЬ =======================
install_queue() {  # имя очереди, URI
  local name="$1" uri="$2" d
  command -v lpadmin >/dev/null 2>&1 || die "Нет CUPS. Установите: apt-get install cups"
  if lpadmin -p "$name" -E -v "$uri" -m everywhere 2>/dev/null; then
    ok "Драйвер подобран автоматически (IPP Everywhere)"
  else
    local model; model=$(ask "Модель принтера для поиска драйвера (например 1020 или M125)")
    mapfile -t drv < <(lpinfo -m 2>/dev/null | grep -i -- "${model:-generic}" || true)
    [ ${#drv[@]} -gt 0 ] || mapfile -t drv < <(lpinfo -m 2>/dev/null | grep -i generic || true)
    [ ${#drv[@]} -gt 0 ] || die "Драйверов не найдено (lpinfo -m пуст)."
    d=$(choose_item "Выберите драйвер:" "${drv[@]}") || die "Отменено."
    lpadmin -p "$name" -E -v "$uri" -m "${d%% *}" || die "lpadmin не смог подключить принтер."
  fi
  lpadmin -p "$name" -o printer-is-shared=false
  echo
  ok "Принтер $name подключён"
  if yes_no "Напечатать тестовую страницу?"; then
    if [ -f /usr/share/cups/data/testprint ]; then
      lp -d "$name" /usr/share/cups/data/testprint || warn "Не удалось отправить задание"
    else
      echo "Проверка печати" | lp -d "$name" || warn "Не удалось отправить задание"
    fi
  fi
}

# ======================= МЕНЮ =======================
M1="Открыть доступ к принтеру этого компьютера (для Windows и Linux)"
M2="Подключить принтер с компьютера Windows"
M3="Подключить принтер с другого компьютера Linux"
ch=$(choose_item "Что сделать?" "$M1" "$M2" "$M3") || { echo "Выход. Ничего не изменено."; exit 0; }
case "$ch" in
  "$M1") share ;;
  "$M2") connect_windows ;;
  "$M3") connect_linux ;;
esac
